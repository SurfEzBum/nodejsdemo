# nodejsdemo
Simple NodeJS demo using Azure App Services and PostgreSQL.